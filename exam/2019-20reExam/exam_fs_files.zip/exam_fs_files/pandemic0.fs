(* Basic simulation of people on a board *)

open System

(* Some utilities and operations on two-dimensional vectors *)
type vec2 = double * double

let sqr x : double = x*x

let dist ((x1,y1):vec2) ((x2,y2):vec2) : double =
    Math.Sqrt(sqr(x2-x1) + sqr(y2-y1))

let to_polar ((x,y):vec2) : vec2 =
    (dist (0.0,0.0) (x,y),
     Math.Atan2(y,x))

let from_polar ((r,phi):vec2) : vec2 =
    (r * Math.Cos phi,
     r * Math.Sin phi)

(* A few general utility functions *)
let count f ps =
    List.fold (fun acc p -> if f p then acc+1 else acc) 0 ps

let maxBy (f: 'a -> int) (ss: 'a list) : int =
    List.fold (fun m s -> max (f s) m) 0 ss

(* Random numbers *)
let rand : unit -> double =  (* return a double in the range [0;1[ *)
  let g = Random()
  in fun () -> g.NextDouble()

(* Types *)
type time = int
type state = OK of time | DEAD of time
type person = {id: int;
               age: int;
               state: state;
               pos: vec2;
               vel: vec2}

(* Query on a person's state *)
let isDead (p:person) : bool =
  match p.state with
    | DEAD _ -> true
    | _ -> false

(* Settings *)
type settings = {oldAgeDeathRate: double;
                 dirChangeRate: double}

(* Configurations and evaliuation *)

type board = int*int
type conf = {board:board; persons:person list}

(* Function for computing the next position of a person, given a board
   definition and the person's current position and velocity *)

let next_pos (board:board) (pos:vec2) (vel:vec2) : vec2 * vec2 =
    let coord (b:double) (x:double) (v:double) : double * double =
      if v+x+1.0 > b then (b - (v+x+1.0 - b), -v)
      else if v+x < 0.0 then (-(v+x), -v)
      else (v+x, v)
    let (x, v_x) = coord (double(fst board)) (fst pos) (fst vel)
    let (y, v_y) = coord (double(snd board)) (snd pos) (snd vel)
    in ((x,y), (v_x,v_y))

(* Function that may change the direction of a person *)
let maybe_modify_dir (S:settings) (vel:vec2) : vec2 =
    if dist vel (0.0,0.0) > 0.0 && rand() < S.dirChangeRate
    then let (r,phi) = to_polar vel
         let phi' = 2.0 * Math.PI * rand()
         in from_polar (r, phi')
    else vel

(* Function that may turn an old age OK person into a DEAD person *)
let next_state (S:settings) (C:conf) (p:person) : state =
    match p.state with
      | OK t -> if p.age > 90 && rand() < S.oldAgeDeathRate then DEAD 0
                else OK (t+1)
      | DEAD t -> DEAD (t+1)

let next (S:settings) (C:conf) (p:person) : person =
    let (pos, vel) = next_pos C.board p.pos p.vel
    let state = next_state S C p
    let vel = match state with
              | DEAD _ -> (0.0,0.0)
              | _ -> maybe_modify_dir S vel
    in {id=p.id; age=p.age; state=state; pos=pos; vel=vel}

let next_conf (S:settings) (C:conf) : conf =
    {board= C.board;
     persons= List.map (next S C) C.persons}

let conf0 (S:settings) (board:board) (n:int) : conf =
    {board= board;
     persons= List.init n (fun i ->
                           let pos = (double(fst board)*rand(),
                                      double(snd board)*rand())
                           let vel = (rand(), rand())
                           in {id=i;
                               age=int(100.0*rand());
                               state=OK 0;
                               pos=pos;
                               vel=vel})}

let pr_person (s:state) : string =
  match s with
    | OK _ -> "o"
    | DEAD _ -> "x"

type cell = string

let pr_conf (C:conf) : string =
    let arr_sz = fst C.board * snd C.board
    let arr : cell array = Array.create arr_sz " "
    let set (p:person) : unit =
          let x = int(fst(p.pos))
          let y = int(snd(p.pos))
          in try Array.set arr (x * snd C.board + y) (pr_person p.state)
             with _ -> failwith ("update, x=" + string(x) + ", y=" + string(y))
    let () = List.iter set C.persons
    let (_,l) = Array.fold (fun (i,a) s ->
                            if i+1 = fst C.board * snd C.board
                            then (i+1,"|" :: s :: a)
                            else if (i+1) % (fst C.board) = 0
                            then (i+1, "|\n|" :: s :: a)
                            else (i+1,s::a)) (0,["|"]) arr
    let line = String.init (fst C.board + 2) (fun _ -> "-") + "\n"
    in line +
       String.concat "" (List.rev l) + "\n" +
       line +
       "| o: ok, x: dead\n" + line

type stat = {t:int; dead:int}

let stat (t:int) (C:conf) : stat =
  {t=t;
   dead=count isDead C.persons}

let rec padRight (c:char) (i:int) (s:string) : string =
  if s.Length >= i then s
  else padRight c i (s+string(c))

let rec padLeft (c:char) (i:int) (s:string) : string =
  if s.Length >= i then s
  else padLeft c i (string(c)+s)

let pr_stats (stats:stat list) : string =
  let pr_t t = padRight ' ' 4 (string(t) + ":")
  let pr_line (s:stat) : string =
    padLeft ' ' (s.dead+1) "x"
  in String.concat "\n" (List.map (fun s -> pr_t (s.t) + pr_line s) stats)

let run S (T:int) (C:conf) : conf * stat list =
  let rec loop acc (t:int) (C:conf) =
    if t > T then (C,List.rev acc)
    else loop (stat t C::acc) (t+1) (next_conf S C)
  in loop [] 0 C

let main () =
  let P = 100                       (* Initial number of persons *)
  let T = 20                        (* Time steps *)
  let S = {oldAgeDeathRate = 0.01;  (* The rate at which people older than 90
                                       years of age die for each time step *)
           dirChangeRate = 0.1}     (* The rate at which people change
                                       direction *)
  let C0 = conf0 S (40,20) P        (* The initial board configuration *)
  let (C,stats) = run S T C0
  let deaths = count isDead C.persons
  in printf "Run with T (time steps) = %d\n" T
   ; printf "%s\n" "Final Configuration:"
   ; printf "%s\n" (pr_conf C)
   ; printf "%s\n" "Evaluation statistics:"
   ; printf "%s\n\n" (pr_stats stats)
   ; printf "Deaths: %d / %d\n" deaths P

let () = main ()
